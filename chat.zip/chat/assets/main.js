const socket = io()
const message = document.querySelector('.message')
const form = document.querySelector('.form')
const input = document.querySelector('.input')
const nameBlock = document.querySelector('.name')

const userName = prompt ('ваше имя: ' );
nameBlock.innerHTML = userName

form.addEventListener('submit', (e) => {
    e.preventDefault()

    if (input.value) {
        socket.emit('сообщение чата', {
            message: input.value ,
            name: userName
        })
       input.value = ''
    }
})

socket.on('сообщение чата' , (data) => {
   const item = document.createElement('li')
   item.innerHTML = data.name + ': ' + data.message
   message.appendChild(item)
})